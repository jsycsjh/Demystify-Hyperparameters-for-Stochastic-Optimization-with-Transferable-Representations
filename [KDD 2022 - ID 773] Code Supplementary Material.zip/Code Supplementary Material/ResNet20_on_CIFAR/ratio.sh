python main.py --lr 0.005 --bs 16 --output_dir ratio_result_1
python main.py --lr 0.01 --bs 32 --output_dir ratio_result_2
python main.py --lr 0.02 --bs 64 --output_dir ratio_result_3
python main.py --lr 0.04 --bs 128 --output_dir ratio_result_4
python main.py --lr 0.08 --bs 256 --output_dir ratio_result_5
python main.py --lr 0.16 --bs 512 --output_dir ratio_result_6
python main.py --lr 0.32 --bs 1024 --output_dir ratio_result_7
python main.py --lr 0.64 --bs 2048 --output_dir ratio_result_8