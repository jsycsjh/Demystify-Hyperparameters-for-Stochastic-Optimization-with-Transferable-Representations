python main.py --lr 0.01 --bs 100 --output_dir ratio_result_1
python main.py --lr 0.02 --bs 200 --output_dir ratio_result_2
python main.py --lr 0.03 --bs 300 --output_dir ratio_result_3
python main.py --lr 0.04 --bs 400 --output_dir ratio_result_4
python main.py --lr 0.05 --bs 500 --output_dir ratio_result_5
python main.py --lr 0.06 --bs 600 --output_dir ratio_result_6
python main.py --lr 0.07 --bs 700 --output_dir ratio_result_7
python main.py --lr 0.1 --bs 1000 --output_dir ratio_result_8
