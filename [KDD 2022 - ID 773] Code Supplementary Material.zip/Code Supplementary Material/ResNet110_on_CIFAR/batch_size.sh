python main.py --bs 1024 --output_dir batch_new_new_result_5
python main.py --bs 700 --output_dir batch_new_new_result_6
python main.py --bs 800 --output_dir batch_new_new_result_7
python main.py --bs 900 --output_dir batch_new_new_result_8
python main.py --bs 600 --output_dir batch_new_new_result_9
python main.py --bs 64 --output_dir batch_new_new_result_1
python main.py --bs 128 --output_dir batch_new_new_result_2
python main.py --bs 256 --output_dir batch_new_new_result_3
python main.py --bs 512 --output_dir batch_new_new_result_4



