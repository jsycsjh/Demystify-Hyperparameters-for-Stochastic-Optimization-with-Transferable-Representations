Versions:
python == 3.6.3
pytorch == 1.5.1
torchvision == 0.6.1
cudatoolkit == 9.2