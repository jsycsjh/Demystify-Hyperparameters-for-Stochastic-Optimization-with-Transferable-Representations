import os

from numpy import linalg as LA
from scipy.linalg import svdvals
import numpy as np
import matplotlib.pyplot as plt
import utils
from scipy.stats import ortho_group
from utils.qhm import alpha_solver, beta_solver, nu_solver, qhm_rate, qhm

d=20

plt.rcParams.update({'font.size': 30})
L = 10.0
mu = 0.1
b = np.linspace(3.0, 1.0, d)
rot_m = ortho_group.rvs(dim=d)
A = rot_m.T.dot(np.diag(np.linspace(mu,L,d))).dot(rot_m)
noise = 0.03
noise_cov = noise*np.eye(d)
w_opt = np.linalg.inv(A).dot(b)

def f(w):
    return 0.5 * w.T.dot(A).dot(w) - b.dot(w)

def g(w):
    return A.dot(w) - b + np.random.multivariate_normal(np.zeros(d), 
                                                        noise_cov, size=1).squeeze()

f_opt = f(w_opt)
seq_result = {}
w_init = w_opt

theoretical_rate = {}
sigma_term = {}
T=100
alphas = np.linspace(0.01, 1.5, 30)
betas = np.linspace(0.0, 0.999, 30)
def gen_plots(nu, dim, T=100, thresh=0.2):  
    alphas = np.linspace(0.01, 1.5, 30)
    betas = np.linspace(0.0, 0.999, 30)
    results_arr = np.empty((alphas.shape[0], betas.shape[0]))
    alphas_XY = np.empty((alphas.shape[0], betas.shape[0]))
    betas_XY = np.empty((alphas.shape[0], betas.shape[0]))
    results = {}
    sigma_rate = np.empty((alphas.shape[0], betas.shape[0]))
    for i, alpha in enumerate(alphas):
        for j, beta in enumerate(betas):
            block_1 = np.eye(dim)*beta
            block_2 = (1-beta)*A
            block_3 = np.eye(dim)*(-alpha*beta*nu)
            block_4 = np.eye(dim)-alpha*(1-nu*beta)*A
            H = np.block([[block_1,block_2],[block_3,block_4]])
            rate = qhm_rate(alpha, beta, nu, [mu, L])
            sig_max = np.max(svdvals(H))
            sigma_rate[i,j] = np.abs(1 + (1-rate**2)*(sig_max**2-rate**2))
            if sigma_rate[i,j]>10:
                sigma_rate[i,j]=10
            if alpha >= 2 * (1 + beta) / (L * (1 + beta * (1 - 2 * nu))):
                results[alpha, beta] = thresh
            else:
                _, results[alpha, beta] = qhm(w_opt, alpha, beta, nu, f, g, dim=dim, T=T, avg_sz=T)
                results[alpha, beta] -= f_opt
                if results[alpha, beta] > thresh:
                    results[alpha, beta] = thresh
            
            results_arr[i, j] = results[alpha, beta]
            
            alphas_XY[i, j] = alpha
            betas_XY[i, j] = beta
    return(alphas_XY, betas_XY,sigma_rate, nu)
    
fig = plt.figure(figsize=(20, 8))
alphas_XY, betas_XY, sigma_rate, nu = gen_plots(nu=1.0, dim=d, thresh=1.0)

plt.subplot(1,2,1)
CS = plt.contourf(alphas_XY, betas_XY, sigma_rate, 30, cmap=plt.cm.binary)
plt.ylim(0.0, 1.0)
plt.xlabel('$\\alpha$')
plt.ylabel('$\\beta$')
plt.title("$\\nu={}$".format(nu)+"$\quad Q={}$".format(L/mu), y=1.02)
conv_bnds_alpha = [(alpha * L - 2) / (2 - alpha * L * (1 - 2 * nu)) for alpha in alphas]
plt.plot(alphas, conv_bnds_alpha, c="r")
cbar = plt.colorbar(CS)
cbar.remove()
alphas_XY, betas_XY, sigma_rate, nu = gen_plots(nu=0.5, dim=d, thresh=0.5)
plt.subplot(1,2,2)
CS = plt.contourf(alphas_XY, betas_XY, sigma_rate, 30, cmap=plt.cm.binary)
plt.ylim(0.0, 1.0)
plt.xlabel('$\\alpha$')
plt.ylabel('$\\beta$')
plt.title("$\\nu={}$".format(nu)+"$\quad Q={}$".format(L/mu), y=1.02)
conv_bnds_alpha = [(alpha * L - 2) / (2 - alpha * L * (1 - 2 * nu)) for alpha in alphas]
plt.plot(alphas, conv_bnds_alpha, c="r")
cbar = plt.colorbar(CS)

fig.savefig('quadratic_q_100.eps', format='eps')   

d=20

plt.rcParams.update({'font.size': 30})
L = 6.0
mu = 0.1
b = np.linspace(3.0, 1.0, d)
rot_m = ortho_group.rvs(dim=d)
A = rot_m.T.dot(np.diag(np.linspace(mu,L,d))).dot(rot_m)
noise = 0.03
noise_cov = noise*np.eye(d)
w_opt = np.linalg.inv(A).dot(b)

def f(w):
    return 0.5 * w.T.dot(A).dot(w) - b.dot(w)

def g(w):
    return A.dot(w) - b + np.random.multivariate_normal(np.zeros(d), 
                                                        noise_cov, size=1).squeeze()

f_opt = f(w_opt)
seq_result = {}
w_init = w_opt

theoretical_rate = {}
sigma_term = {}
T=100
alphas = np.linspace(0.01, 1.5, 30)
betas = np.linspace(0.0, 0.999, 30)
def gen_plots(nu, dim, T=100, thresh=0.2):  
    alphas = np.linspace(0.01, 1.5, 30)
    betas = np.linspace(0.0, 0.999, 30)
    results_arr = np.empty((alphas.shape[0], betas.shape[0]))
    alphas_XY = np.empty((alphas.shape[0], betas.shape[0]))
    betas_XY = np.empty((alphas.shape[0], betas.shape[0]))
    results = {}
    sigma_rate = np.empty((alphas.shape[0], betas.shape[0]))
    for i, alpha in enumerate(alphas):
        for j, beta in enumerate(betas):
            block_1 = np.eye(dim)*beta
            block_2 = (1-beta)*A
            block_3 = np.eye(dim)*(-alpha*beta*nu)
            block_4 = np.eye(dim)-alpha*(1-nu*beta)*A
            H = np.block([[block_1,block_2],[block_3,block_4]])
            rate = qhm_rate(alpha, beta, nu, [mu, L])
            sig_max = np.max(svdvals(H))
            sigma_rate[i,j] = np.abs(1 + (1-rate**2)*(sig_max**2-rate**2))
            if sigma_rate[i,j]>10:
                sigma_rate[i,j]=10
            if alpha >= 2 * (1 + beta) / (L * (1 + beta * (1 - 2 * nu))):
                results[alpha, beta] = thresh
            else:
                _, results[alpha, beta] = qhm(w_opt, alpha, beta, nu, f, g, dim=dim, T=T, avg_sz=T)
                results[alpha, beta] -= f_opt
                if results[alpha, beta] > thresh:
                    results[alpha, beta] = thresh
            
            results_arr[i, j] = results[alpha, beta]
            
            alphas_XY[i, j] = alpha
            betas_XY[i, j] = beta
    return(alphas_XY, betas_XY,sigma_rate, nu)
    
fig = plt.figure(figsize=(20, 8))
alphas_XY, betas_XY, sigma_rate, nu = gen_plots(nu=1.0, dim=d, thresh=1.0)

plt.subplot(1,2,1)
CS = plt.contourf(alphas_XY, betas_XY, sigma_rate, 30, cmap=plt.cm.binary)
plt.ylim(0.0, 1.0)
plt.xlabel('$\\alpha$')
plt.ylabel('$\\beta$')
plt.title("$\\nu={}$".format(nu)+"$\quad Q={}$".format(L/mu), y=1.02)
conv_bnds_alpha = [(alpha * L - 2) / (2 - alpha * L * (1 - 2 * nu)) for alpha in alphas]
plt.plot(alphas, conv_bnds_alpha, c="r")
cbar = plt.colorbar(CS)
cbar.remove()
alphas_XY, betas_XY, sigma_rate, nu = gen_plots(nu=0.5, dim=d, thresh=0.5)
plt.subplot(1,2,2)
CS = plt.contourf(alphas_XY, betas_XY, sigma_rate, 30, cmap=plt.cm.binary)
plt.ylim(0.0, 1.0)
plt.xlabel('$\\alpha$')
plt.ylabel('$\\beta$')
plt.title("$\\nu={}$".format(nu)+"$\quad Q={}$".format(L/mu), y=1.02)
conv_bnds_alpha = [(alpha * L - 2) / (2 - alpha * L * (1 - 2 * nu)) for alpha in alphas]
plt.plot(alphas, conv_bnds_alpha, c="r")
cbar = plt.colorbar(CS)

fig.savefig('quadratic_q_60.eps', format='eps')   



