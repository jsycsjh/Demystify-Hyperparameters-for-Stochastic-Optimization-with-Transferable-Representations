python main.py --lr 1 --bs 1000 --output_dir ratio_new_result_1
python main.py --lr 0.8 --bs 800 --output_dir ratio_new_result_2
python main.py --lr 0.6 --bs 600 --output_dir ratio_new_result_3
python main.py --lr 0.4 --bs 400 --output_dir ratio_new_result_4
python main.py --lr 0.3 --bs 300 --output_dir ratio_new_result_5
python main.py --lr 0.2 --bs 200 --output_dir ratio_new_result_6
python main.py --lr 0.1 --bs 100 --output_dir ratio_new_result_7
