python main.py --lr 2 --bs 2000 --output_dir ratio_new_result_7
python main.py --lr 1 --bs 1000 --output_dir ratio_new_result_6
python main.py --lr 0.5 --bs 500 --output_dir ratio_new_result_5
python main.py --lr 0.25 --bs 250 --output_dir ratio_new_result_1
python main.py --lr 0.1 --bs 100 --output_dir ratio_new_result_2
python main.py --lr 0.05 --bs 50 --output_dir ratio_new_result_3
python main.py --lr 0.03 --bs 30 --output_dir ratio_new_result_4



